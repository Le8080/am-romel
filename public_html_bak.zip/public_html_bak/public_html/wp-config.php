<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'u794288319_webdb');

/** MySQL database username */
define('DB_USER', 'u794288319_dbadm');

/** MySQL database password */
define('DB_PASSWORD', '4TA*Ape_Wecu');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'bC_v? ~:=D.p?Al4D q qqjR|(}?kWQQoGd? cm=OGi(c%[G)/FAlvcd1-/kkW3k');
define('SECURE_AUTH_KEY',  'njF Y]Wx1tYCi=N]c+^/%b6!Ck#?Nc7?rT^),nXim6-r~-gRz,$LPyu-(WSjgZ7(');
define('LOGGED_IN_KEY',    'Hr7lAX7bV~3]m4EWCeYk,C]Mld f0]BE{+G1w4)uT4VeUD[e,%SROk?HZ@ P#E8_');
define('NONCE_KEY',        'cKRlTLQ_HpM,h1wl<q@q$o?u[F;z<ttTXO^i%wKfo_`TJ$Yic|}OsE()tr;dsYt#');
define('AUTH_SALT',        'AJ2~qn{/LR!dL27, Inf6isY/X4GIqD R!,a:Q7$/00_jq$-8!(p2}FV6fZ%)rF{');
define('SECURE_AUTH_SALT', ')Gz0]4CGJj@A$bIMo22[ 5Y)go,RMqLJg<1[BkDh^A0m(rFBX,w<%)a:|0G 1)<c');
define('LOGGED_IN_SALT',   'zOQ;l/F}`)]haIv4p]4p:iRh!q[$1$M+J|1E*GZlv#pZKvB`>iMro[nck&J,7e=7');
define('NONCE_SALT',       'UM)SADr{^]QGXTWpMl XVww-gk,gw]<)*/B.6`AU%ee0(TEBd2u=wzqGs>e_)5x}');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

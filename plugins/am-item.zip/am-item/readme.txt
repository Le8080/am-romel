Plugin Name: AM Search-Listing
Description: Search Object or Items Made on AM plugin
Plugin URI: https://automeans.com
Author: Leah Fuentes
Version: 1.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.text